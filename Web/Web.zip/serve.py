import os, http.server, socketserver

os.chdir("/Users/jenniferaguilar/Desktop/Claude")
PORT = 3456
Handler = http.server.SimpleHTTPRequestHandler
with socketserver.TCPServer(("", PORT), Handler) as httpd:
    httpd.serve_forever()
